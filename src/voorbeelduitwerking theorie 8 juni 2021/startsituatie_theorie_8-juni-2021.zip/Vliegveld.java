// code voor opgave 4
//
public class Vliegveld
{
	
	public Vliegveld( int grootte ) { /*...todo...*/ }

	public void zetBinnen( Vliegtuig v, int plek ) { /*...todo...*/ }

	public void print() { /*...todo...*/ }

	public Vliegtuig haalEruit( int plek ) { /*...todo...*/ }

	public int zetOpEersteVrijePlek( Vliegtuig v ) { /*...todo...*/ }
}
